# iService (GitHub Pages)

This folder is a ready-to-publish static site.

## Publish
1. Create a repo (e.g., `iservice-site`)
2. Upload all files in this folder to the repo root
3. GitHub → Settings → Pages → Deploy from branch → `main` / root
4. Your site will go live on GitHub Pages.

## Replace placeholders
- Put your Covenant PDF at: `assets/docs/iservice-covenant.pdf`
- Update contact details in `contact.html`
- Replace any placeholder copy pages with final content.

## Brand
Quiet Regulatory Body tone.
Core values: ICE‑S (Integrity, Customer Stewardship, Excellence, Selflessness).
